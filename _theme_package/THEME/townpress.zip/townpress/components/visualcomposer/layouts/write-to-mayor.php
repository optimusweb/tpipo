<?php return array(
	'name' => __( '#Write To Mayor', 'lsvrtheme' ),
	'custom_class' => 'lsvr-layout-template lsvr-layout-template-write-to-mayor',
	'content' => '[vc_row][vc_column width="1/1"][lsvr_team_member wpautop="yes" portrait="1835" name="Adam Ganizani" role="Town Mayor" social_icons="fa fa-twitter,https://twitter.com/MyTwitterProfile|fa fa-facebook,https://www.facebook.com/MyTwitterProfile"]You can ask me anything and I will try to reply within 24 hours.[/lsvr_team_member][contact-form-7 id="1937"][/vc_column][/vc_row]'
); ?>
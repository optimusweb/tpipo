<?php return array(
	'name' => __( '#bbPress Lost Password', 'lsvrtheme' ),
	'custom_class' => 'lsvr-layout-template lsvr-layout-template-lost-pass',
	'content' => '[vc_row][bbp-lost-pass][/vc_row]'
); ?>